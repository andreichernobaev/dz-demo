export class FileElementResponse {
	url: string;
	name: string;
}