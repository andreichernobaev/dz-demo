export enum ImageType {
	Png = 'png',
	Jpg = 'jpg',
	Webp = 'webp',
	Unknown = 'unknown',
}
