export enum ImageRotation {
	Degree90 = 90,
	Degree180 = 180,
	Degree270 = 270,
}