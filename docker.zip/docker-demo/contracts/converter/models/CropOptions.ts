export class CropOptions {
	left: number;
	top: number;
	width: number;
	height: number;
}