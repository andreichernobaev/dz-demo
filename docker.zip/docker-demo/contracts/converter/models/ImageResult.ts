import { ImageRequirement } from '.';

export class ImageResult extends ImageRequirement {
	image: number[];
}