# Демо для курса по Docker

Сборка сервиса
```
docker build -t test -f apps/api/Dockerfile .
```